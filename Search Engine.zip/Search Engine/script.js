// On document load, retrieve search history
window.onload = function() {
    displayHistory();
};

// Event listeners
document.getElementById('searchButton').addEventListener('click', addSearch);
document.getElementById('clearButton').addEventListener('click', clearHistory);

// Function to add search to history
function addSearch() {
    const searchInput = document.getElementById('searchInput').value;
    if (searchInput) {
        let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];
        searchHistory.push(searchInput);
        localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
        displayHistory();
        document.getElementById('searchInput').value = ''; // Clear input field
    }
}

// Function to display search history
function displayHistory() {
    let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];
    const historyList = document.getElementById('historyList');
    historyList.innerHTML = ''; // Clear previous list

    searchHistory.forEach((term, index) => {
        let li = document.createElement('li');
        li.textContent = `${index + 1}. ${term}`;
        historyList.appendChild(li);
    });
}

// Function to clear search history
function clearHistory() {
    localStorage.removeItem('searchHistory');
    displayHistory();
}
